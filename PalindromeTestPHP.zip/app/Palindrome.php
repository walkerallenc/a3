<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Palindrome extends Model
{
    //
}
