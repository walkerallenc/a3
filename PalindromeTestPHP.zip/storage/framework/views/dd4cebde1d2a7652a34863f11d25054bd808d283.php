          




<?php $__env->startSection('title'); ?>
    Palindrome test
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>
    <link href="/css/acw.css" type='text/css' rel='stylesheet'>
<?php $__env->stopPush(); ?>


          

<?php $__env->startSection('content'); ?>
    <form method='GET' action='/tests/palindrome'>
        <h3><input type='text' name='enteredWord' id='enteredWord' value='<?php echo e(isset($enteredWord) ? $enteredWord : ''); ?>'><==Enter your palindrome candidate string here.</h3>
        <p class="required">*** this is a required field ***</p>
        <br>
        <input type='submit' class='/css/acw.css' value='Submit palindrome test string(s).'>
    </form>


          
          

<?php if(count($errors) > 0): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php else: ?>
    <?php if($enteredWord != null): ?> 
        <h3>The original word string is "<em><?php echo e($enteredWord); ?></em>" and the reversed word string is "<em><?php echo e($WordAccumulator); ?></em>".</h3><br>
        <h3>The results are "<em><?php echo e($palindromeresults); ?></em>".</h3>
    <?php endif; ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>