<!DOCTYPE html>
<html>
<head>
    <title>
        <?php echo $__env->yieldContent('title', 'Foobooks default title'); ?>
    </title>

    <meta charset='utf-8'>
    <link href="/css/foobooks.css" type='text/css' rel='stylesheet'>

    <?php echo $__env->yieldPushContent('head'); ?>

</head>
<body>

    <header>
        <img
        src='/images/scrabbleimage.jpg'
        style='width:300px'
        alt='Scrabble Image'>
    </header>



    <section>
        <?php echo $__env->yieldContent('scrabblelettersimage'); ?>
    </section>

    <section>
        <?php echo $__env->yieldContent('scrabblewordcontent'); ?>
    </section>

    <section>
        <?php echo $__env->yieldContent('radiobuttonscontent'); ?>
    </section>

    <section>
        <?php echo $__env->yieldContent('checkboxcontent'); ?>
    </section>

    <section>
        <?php echo $__env->yieldContent('contentacw'); ?>
    </section>

    <section>
        <?php echo $__env->yieldContent('content'); ?>
    </section>

    <footer>
        &copy; <?php echo e(date('Y')); ?>

    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

    <?php echo $__env->yieldPushContent('body'); ?>

</body>
</html>