<?php $__env->startSection('title'); ?>
    New book
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Add a new book</h1>

    <form method='POST' action='/books/new'>
        <?php echo e(csrf_field()); ?>


        <label for='title'>Title</label>
        <input type='text' name='title' id='title'>
        <input type='submit' value='Add book'>
    </form>

<?php if($errors->get('title')): ?>
    <ul>
        <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>