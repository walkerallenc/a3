<?php $__env->startSection('title'); ?>
    Search acw
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Search</h1>

    <form method='GET' action='/books/search'>

        <label for='searchTerm'>Search by title:</label>
        <input type='text' name='searchTerm' id='searchTerm' value='<?php echo e(isset($searchTerm) ? $searchTerm : ''); ?>'>
        
         
        <input type='checkbox' name='caseSensitive' <?php echo e(($caseSensitive) ? 'CHECKED' : ''); ?> >
        <label>case sensitive</label>

        <br>
        <input type='submit' class='btn btn-primary btn-small'>

    </form>

<?php if($searchTerm != null): ?>
    <h2>Results for query: <em><?php echo e($searchTerm); ?></em></h2>

    <?php if(count($searchResults) == 0): ?>
        No matches found.
    <?php else: ?>
        <div class='book'>
            <?php $__currentLoopData = $searchResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <h3><?php echo e($title); ?></h3>
                <h4>by <?php echo e($book['author']); ?></h4>
                <img src='<?php echo e($book['cover']); ?>'>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>