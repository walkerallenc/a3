<?php $__env->startSection('title'); ?>
    All the books
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='book'>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2><?php echo e($book->title); ?></h2>
            <img src='<?php echo e($book->cover); ?>'>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>