<!DOCTYPE html>
<html>
<head>
    <title>
        <?php echo $__env->yieldContent('title', 'Palindrome Test title'); ?>
    </title>

    <meta charset='utf-8'>
    <link href="/css/acw.css" type='text/css' rel='stylesheet'>

    <?php echo $__env->yieldPushContent('head'); ?>

</head>
<body>

    <header>
     <h2>Palindrome Test</h2>
    </header>

    <section>
        <?php echo $__env->yieldContent('content'); ?>
    </section>

    <footer>
        &copy; <?php echo e(date('Y')); ?>

    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

    <?php echo $__env->yieldPushContent('body'); ?>

</body>
</html>