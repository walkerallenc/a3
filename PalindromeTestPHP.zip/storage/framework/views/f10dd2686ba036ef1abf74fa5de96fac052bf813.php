          




<?php $__env->startSection('title'); ?>
    Scrabble Word Calculator
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>
    <link href="/css/acw.css" type='text/css' rel='stylesheet'>
<?php $__env->stopPush(); ?>


          

<?php $__env->startSection('content'); ?>
    <form method='GET' action='/games/scrabble'>
        <h3><input type='text' name='enteredWord' id='enteredWord' value='<?php echo e(isset($enteredWord) ? $enteredWord : ''); ?>'><==Enter your word here</h3>
        <p class="required">*** this is a required field ***</p>
        <input type='radio' name='multipliercheck' id='single' value='single' <?php echo e(($multipliercheck=='single' ? 'checked=true' : '')); ?>>None
        <br>
        <input type='radio' name='multipliercheck' id='double' value='double' <?php echo e(($multipliercheck=='double' ? 'checked=true' : '')); ?>>Double word
        <br>
        <input type='radio' name='multipliercheck' id='triple' value='triple' <?php echo e(($multipliercheck=='triple' ? 'checked=true' : '')); ?>>Triple word
        <br>
        <br>
        <label>Include 50 point Bingo</label>
        <input type='checkbox' name='includeBingo' <?php echo e(($includeBingo ? 'CHECKED' : '')); ?>> Yes
        <br>
        <br>
        <input type='submit' class='/css/acw.css' value='Calculate scrabble word value'>
    </form>


          
          

<?php if(count($errors) > 0): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php else: ?>
    <?php if($enteredWord != null): ?> 
        <h3>The scrabble word value of "<em><?php echo e($enteredWord); ?></em>" is "<em><?php echo e($total); ?></em>".</h3>
    <?php endif; ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>