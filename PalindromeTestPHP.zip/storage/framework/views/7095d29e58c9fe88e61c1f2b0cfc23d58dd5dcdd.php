<?php $__env->startSection('title'); ?>
    Scrabble wWrd Calculator
<?php $__env->stopSection(); ?>


<?php $__env->startPush('head'); ?>
    <link href="/css/books/show.css" type='text/css' rel='stylesheet'>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('scrabblewordcontent'); ?>
           <h1>Enter your word here: <input type='text' name='userlogin' id='userlogin'></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('radiobuttonscontent'); ?>
           <input type='radio' name='securitycheck' id='securitycheck' value='checkenabled' 'CHECKED'> None<br>
           <input type='radio' name='securitycheck' id='securitycheck' value='checkdisabled' > Double word score<br>
           <input type='radio' name='securitycheck' id='securitycheck' value='checkdisabled' > Triple word score
<?php $__env->stopSection(); ?>

<?php $__env->startSection('checkboxcontent'); ?>
           <h1>put checkbox here: <?php echo e($title); ?></h1>

  <label for='caseSensitivity'>Case sensitivity on </label>
  <input type='checkbox' name='caseSensitive[]' id='caseSensitivity' value='caseon' > Yes

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentacw'); ?>
    <?php if($title): ?>
        <h1>Show scrabble word acw: <?php echo e($title); ?></h1>
  <input type='submit' class='acw.css'>
    <?php else: ?>
        <h1>No book chosen acw</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contentacw'); ?>
    <?php if($title): ?>
        <h1>Show scrabble word acw: <?php echo e($title); ?></h1><br>
        <input type='submit' class='acw.css'>
    <?php else: ?>
        <h1>No book chosen acw</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('body'); ?>
    <script src="/js/books/show.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>