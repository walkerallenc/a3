<?php $__env->startSection('title'); ?>
    Show book
<?php $__env->stopSection(); ?>


<?php $__env->startPush('head'); ?>
    <link href="/css/books/show.css" type='text/css' rel='stylesheet'>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <?php if($title): ?>
        <h1>Show books: <?php echo e($title); ?></h1>
    <?php else: ?>
        <h1>No book chosen</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('body'); ?>
    <script src="/js/books/show.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>